﻿namespace Methods.UnitTests
{
    public class PalindromeClassTests
    {
        [Test, Order(1)]
        public void Test_PalindromeClass_EmptyString1()
        {
            //Arrange
            string input = string.Empty;

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(2)]
        public void Test_PalindromeClass_EmptyString2()
        {
            //Arrange
            string input = "";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(3)]
        public void Test_PalindromeClass_SingleLowerLetterString()
        {
            //Arrange
            string input = "a";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(4)]
        public void Test_PalindromeClass_SingleUpperLetterString()
        {
            //Arrange
            string input = "B";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(5)]
        public void Test_PalindromeClass_EvenLowerLettersStringNonPalindrome()
        {
            //Arrange
            string input = "banana";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(6)]
        public void Test_PalindromeClass_EvenLowerLettersStringPalindrome()
        {
            //Arrange
            string input = "bbbb";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(7)]
        public void Test_PalindromeClass_EvenUpperLettersStringNonPalindrome()
        {
            //Arrange
            string input = "BANANA";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(8)]
        public void Test_PalindromeClass_EvenUpperLettersStringPalindrome()
        {
            //Arrange
            string input = "BBBB";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(9)]
        public void Test_PalindromeClass_OddLowerLettersStringNonPalindrome()
        {
            //Arrange
            string input = "cebry";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(10)]
        public void Test_PalindromeClass_OddLowerLettersStringPalindrome()
        {
            //Arrange
            string input = "racecar";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(11)]
        public void Test_PalindromeClass_OddUpperLettersStringNonPalindrome()
        {
            //Arrange
            string input = "CEBRY";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(12)]
        public void Test_PalindromeClass_OddUpperLettersStringPalindrome()
        {
            //Arrange
            string input = "RACECAR";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(13)]
        public void Test_PalindromeClass_SentencePalindrome()
        {
            //Arrange
            string input = "Was it a car or a cat I saw";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(14)]
        public void Test_PalindromeClass_SentenceNonPalindrome()
        {
            //Arrange
            string input = "Neptune is a planet";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(15)]
        public void Test_PalindromeClass_NumbersPalindrome()
        {
            //Arrange
            string input = "9999";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(16)]
        public void Test_PalindromeClass_NumbersNonPalindrome()
        {
            //Arrange
            string input = "1234";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(17)]
        public void Test_PalindromeClass_NumbersUpperLettersNonPalindrome()
        {
            //Arrange
            string input = "123LKA321";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(18)]
        public void Test_PalindromeClass_NumbersLowerLettersNonPalindrome()
        {
            //Arrange
            string input = "123lka321";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(19)]
        public void Test_PalindromeClass_NumbersLowerLettersPalindrome()
        {
            //Arrange
            string input = "123aba321";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(20)]
        public void Test_PalindromeClass_NumbersUpperLettersPalindrome()
        {
            //Arrange
            string input = "123ABA321";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(21)]
        public void Test_PalindromeClass_SpecialSymbolsNonPalindrome()
        {
            //Arrange
            string input = "#$%";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(22)]
        public void Test_PalindromeClass_SpecialSymbolsPalindrome()
        {
            //Arrange
            string input = "*^^*";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(23)]
        public void Test_PalindromeClass_SpecialSymbolsLettersPalindrome()
        {
            //Arrange
            string input = "*^AA^*";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(24)]
        public void Test_PalindromeClass_SpecialSymbolsLettersNonPalindrome()
        {
            //Arrange
            string input = "*^AB^*";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(25)]
        public void Test_PalindromeClass_SpecialSymbolsNumbersPalindrome()
        {
            //Arrange
            string input = "*^99^*";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(26)]
        public void Test_PalindromeClass_SpecialSymbolsNumbersNonPalindrome()
        {
            //Arrange
            string input = "*^91^*";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(27)]
        public void Test_PalindromeClass_MixedAllPalindrome()
        {
            //Arrange
            string input = "*^9aEEa9^*";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(28)]
        public void Test_PalindromeClass_MixedAllNonPalindrome()
        {
            //Arrange
            string input = "*^9aKFa9^*";

            //Act
            PalindromeClass runner = new PalindromeClass();
            bool result = runner.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }
    }
}
