﻿namespace Methods
{
    public class MatrixClass
    {
        public bool CheckMatrixEquality(int[,] array1, int[,] array2)
        {
            if ((array1.GetLength(0) != array2.GetLength(0)) || (array1.GetLength(1) != array2.GetLength(1)))
            {
                return false;
            }

            for (int row = 0; row < array1.GetLength(0); row++)
            {
                for (int col = 0; col < array1.GetLength(1); col++)
                {
                    if (array1[row, col] != array2[row, col])
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}
