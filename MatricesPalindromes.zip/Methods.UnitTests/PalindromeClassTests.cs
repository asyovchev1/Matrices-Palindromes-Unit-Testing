﻿namespace Methods.UnitTests
{
    public class PalindromeClassTests
    {
        [Test, Order(1)]
        public void Test_CheckForPalindrome_EmptyString1()
        {
            //Arrange
            string input = string.Empty;

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(2)]
        public void Test_CheckForPalindrome_EmptyString2()
        {
            //Arrange
            string input = "";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(3)]
        public void Test_CheckForPalindrome_SingleLowerLetterString()
        {
            //Arrange
            string input = "a";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(4)]
        public void Test_CheckForPalindrome_SingleUpperLetterString()
        {
            //Arrange
            string input = "B";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(5)]
        public void Test_CheckForPalindrome_EvenLowerLettersStringNonPalindrome()
        {
            //Arrange
            string input = "banana";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(6)]
        public void Test_CheckForPalindrome_EvenLowerLettersStringPalindrome()
        {
            //Arrange
            string input = "bbbb";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(7)]
        public void Test_CheckForPalindrome_EvenUpperLettersStringNonPalindrome()
        {
            //Arrange
            string input = "BANANA";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(8)]
        public void Test_CheckForPalindrome_EvenUpperLettersStringPalindrome()
        {
            //Arrange
            string input = "BBBB";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(9)]
        public void Test_CheckForPalindrome_OddLowerLettersStringNonPalindrome()
        {
            //Arrange
            string input = "cebry";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(10)]
        public void Test_CheckForPalindrome_OddLowerLettersStringPalindrome()
        {
            //Arrange
            string input = "racecar";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(11)]
        public void Test_CheckForPalindrome_OddUpperLettersStringNonPalindrome()
        {
            //Arrange
            string input = "CEBRY";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(12)]
        public void Test_CheckForPalindrome_OddUpperLettersStringPalindrome()
        {
            //Arrange
            string input = "RACECAR";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(13)]
        public void Test_CheckForPalindrome_SentencePalindrome()
        {
            //Arrange
            string input = "Was it a car or a cat I saw";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(14)]
        public void Test_CheckForPalindrome_SentenceNonPalindrome()
        {
            //Arrange
            string input = "Neptune is a planet";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(15)]
        public void Test_CheckForPalindrome_NumbersPalindrome()
        {
            //Arrange
            string input = "9999";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(16)]
        public void Test_CheckForPalindrome_NumbersNonPalindrome()
        {
            //Arrange
            string input = "1234";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(17)]
        public void Test_CheckForPalindrome_NumbersUpperLettersNonPalindrome()
        {
            //Arrange
            string input = "123LKA321";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(18)]
        public void Test_CheckForPalindrome_NumbersLowerLettersNonPalindrome()
        {
            //Arrange
            string input = "123lka321";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(19)]
        public void Test_CheckForPalindrome_NumbersLowerLettersPalindrome()
        {
            //Arrange
            string input = "123aba321";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(20)]
        public void Test_CheckForPalindrome_NumbersUpperLettersPalindrome()
        {
            //Arrange
            string input = "123ABA321";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(21)]
        public void Test_CheckForPalindrome_SpecialSymbolsNonPalindrome()
        {
            //Arrange
            string input = "#$%";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(22)]
        public void Test_CheckForPalindrome_SpecialSymbolsPalindrome()
        {
            //Arrange
            string input = "*^^*";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(23)]
        public void Test_CheckForPalindrome_SpecialSymbolsLettersPalindrome()
        {
            //Arrange
            string input = "*^AA^*";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(24)]
        public void Test_CheckForPalindrome_SpecialSymbolsLettersNonPalindrome()
        {
            //Arrange
            string input = "*^AB^*";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(25)]
        public void Test_CheckForPalindrome_SpecialSymbolsNumbersPalindrome()
        {
            //Arrange
            string input = "*^99^*";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(26)]
        public void Test_CheckForPalindrome_SpecialSymbolsNumbersNonPalindrome()
        {
            //Arrange
            string input = "*^91^*";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(27)]
        public void Test_CheckForPalindrome_MixedAllPalindrome()
        {
            //Arrange
            string input = "*^9aEEa9^*";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(28)]
        public void Test_CheckForPalindrome_MixedAllNonPalindrome()
        {
            //Arrange
            string input = "*^9aKFa9^*";

            //Act
            bool result = PalindromeClass.CheckForPalindrome(input);

            //Assert
            Assert.That(result, Is.False);
        }
    }
}
