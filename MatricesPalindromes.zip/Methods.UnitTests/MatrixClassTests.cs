namespace Methods.UnitTests
{
    public class MatrixClassTests
    {
        [Test, Order(1)]
        public void Test_CheckMatrixEquality_EmptyArrays()
        {
            //Arrange
            int[,] array1 = new int[,] { };
            int[,] array2 = new int[,] { };

            //Act
            bool result = MatrixClass.CheckMatrixEquality(array1, array2);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(2)]
        public void Test_CheckMatrixEquality_EmptyRowsColumns()
        {
            //Arrange
            int[,] array1 = new int[,] { { } };
            int[,] array2 = new int[,] { { } };

            //Act
            bool result = MatrixClass.CheckMatrixEquality(array1, array2);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(3)]
        public void Test_CheckMatrixEquality_AllZeroes()
        {
            //Arrange
            int[,] array1 = new int[,] { { 0, 0 } };
            int[,] array2 = new int[,] { { 0, 0 } };

            //Act
            bool result = MatrixClass.CheckMatrixEquality(array1, array2);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(4)]
        public void Test_CheckMatrixEquality_SamePositiveArrays()
        {
            //Arrange
            int[,] array1 = new int[,] { { 1, 2, 3 }, { 4, 5, 6 } };
            int[,] array2 = new int[,] { { 1, 2, 3 }, { 4, 5, 6 } };

            //Act
            bool result = MatrixClass.CheckMatrixEquality(array1, array2);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(5)]    
        public void Test_CheckMatrixEquality_DifferentPositiveArrays()
        {
            //Arrange
            int[,] array1 = new int[,] { { 1, 2, 3 }, { 4, 5, 6 } };
            int[,] array2 = new int[,] { { 1, 2, 3 }, { 4, 5, 7 } };

            //Act
            bool result = MatrixClass.CheckMatrixEquality(array1, array2);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(6)]
        public void Test_CheckMatrixEquality_SameNegativeArrays()
        {
            //Arrange
            int[,] array1 = new int[,] { { -1, -2, -3 }, { -4, -5, -6 } };
            int[,] array2 = new int[,] { { -1, -2, -3 }, { -4, -5, -6 } };

            //Act
            bool result = MatrixClass.CheckMatrixEquality(array1, array2);

            //Assert
            Assert.That(result, Is.True);
        }

        [Test, Order(7)]
        public void Test_CheckMatrixEquality_DifferentNegativeArrays()
        {
            //Arrange
            int[,] array1 = new int[,] { { -1, -2, -3 }, { -4, -5, -6 } };
            int[,] array2 = new int[,] { { -1, -2, -3 }, { -4, -5, -7 } };

            //Act
            bool result = MatrixClass.CheckMatrixEquality(array1, array2);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(8)]
        public void Test_CheckMatrixEquality_DifferentArraysRows()
        {
            //Arrange
            int[,] array1 = new int[,] { { 1, 2, 3 } };
            int[,] array2 = new int[,] { { 1, 2, 3 }, { 4, 5, 6 } };

            //Act
            bool result = MatrixClass.CheckMatrixEquality(array1, array2);

            //Assert
            Assert.That(result, Is.False);
        }

        [Test, Order(9)]
        public void Test_CheckMatrixEquality_DifferentArraysColumns()
        {
            //Arrange
            int[,] array1 = new int[,] { { 1, 2 }, { 3, 4 } };
            int[,] array2 = new int[,] { { 1, 2, 3 }, { 4, 5, 6 } };

            //Act
            bool result = MatrixClass.CheckMatrixEquality(array1, array2);

            //Assert
            Assert.That(result, Is.False);
        }
    }
}