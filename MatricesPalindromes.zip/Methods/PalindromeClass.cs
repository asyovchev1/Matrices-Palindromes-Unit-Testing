﻿namespace Methods
{
    public class PalindromeClass
    {
        public static bool CheckForPalindrome(string input)
        {
            if (input.Length == 0)
            {
                return false;
            }

            char[] letters = input.ToCharArray();

            input = new string(letters.Where(x => !Char.IsWhiteSpace(x)).ToArray());
            input = input.ToLower();

            for (int i = 0; i < input.Length / 2; i++) 
            { 
                if (input[i] != input[input.Length - i - 1])
                {
                    return false;
                }
            }

            return true;
        }
    }
}
